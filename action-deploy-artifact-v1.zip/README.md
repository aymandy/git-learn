#GitHub Actions deploy Flask to AWS EB

Status of last Deployment:<br>
<img src="https://github.com/aymandy/git-learn/workflows/CI-CD-Pipline-to-aws-ElasticBeanstalk/badge.svg?branch=master">
<br>
